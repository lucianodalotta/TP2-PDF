const PDF= require('pdfkit')
const fs= require('fs')

var doc= new PDF()

doc.pipe(fs.createWriteStream(__dirname+'/example.pdf'))

doc.text('HOLA MUNDO pdf  ',{
    align: 'center'
})
var parrafo= 'Una criptomoneda, criptodivisa o criptoactivo es un medio digital de intercambio que utiliza criptografía fuerte para asegurar las transacciones, controlar la creación de unidades adicionales y verificar la transferencia de activos usando tecnologías de registro distribuido.​​​​'

doc.text(parrafo,{
   
    align: 'justify'

})
doc.image('./img/Criptomonedas.jpg', 30, 400, {width: 300})
.text('', 0, 0);
doc.end()
 console.log('Archivo generado')